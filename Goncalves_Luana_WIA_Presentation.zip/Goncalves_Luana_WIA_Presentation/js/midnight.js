/**
 * Created by luanagoncalves on 11/11/15.
 */
$(document).ready(function(){
    $('nav.fixed').midnight();
});